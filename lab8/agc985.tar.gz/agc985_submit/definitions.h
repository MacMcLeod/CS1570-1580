// Programmer: Anna Case                         Date: 3/8/2017
// File: definitions.h                                Class: CS1580
//Instructor: Rushiraj
// Student Id: 16181344                          Section: E
// Description: stupid definitions
#ifndef DEFINITIONS_H_INCLUDED
#define DEFINITIONS_H_INCLUDED

#include <ctime>
#include <cstdlib>
#include <algorithm>
#include <functional>
#include <iostream>
using namespace std;

//functions
void getInput(int numbers[], int size);
void sort (int numbers[], int size);
void print (int numbers[], int size);
void greetings();
void signoff();

#endif // DEFINITIONS_H_INCLUDED
